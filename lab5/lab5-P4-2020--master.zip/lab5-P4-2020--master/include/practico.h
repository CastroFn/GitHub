#ifndef PRACTICO_H
#define PRACTICO_H
#include "clase.h"

class Practico : public Clase{
  public:
    bool estaHabilitado(string);

    Practico();
    ~Practico();
};
#endif
