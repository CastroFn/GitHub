#ifndef TIPO_CLASE_H
#define TIPO_CLASE_H

enum tipoClase{teorico = 1, practico = 2, monitoreo = 3};

#endif
