#include "../include/dtDocente.h"

dtDocente::dtDocente(){};

string dtDocente::getInstituto() const { return instituto;};

void dtDocente::setInstituto(string i){ this->instituto = i;};

dtDocente::~dtDocente(){};
