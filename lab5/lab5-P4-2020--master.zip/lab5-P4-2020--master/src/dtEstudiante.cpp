#include "../include/dtEstudiante.h"

dtEstudiante::dtEstudiante(){};
void dtEstudiante::setCI(string ci){  this->ci = ci;};
string dtEstudiante::getCI(){ return ci;};

dtEstudiante::~dtEstudiante(){};
