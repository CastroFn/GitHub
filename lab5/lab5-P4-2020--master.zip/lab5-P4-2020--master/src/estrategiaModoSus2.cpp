#include "../include/estrategiaModoSus2.h"
#include "../include/usuario.h"
#include "../include/dtMensaje.h"

EstrategiaModoSus2();

bool aplicaNotificacion(dtMensaje d){return true;};

~EstrategiaModoSus2();
