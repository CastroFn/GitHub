#include "../include/estrategiaNotifs.h"
#include "../include/usuario.h"

void EstrategiaNotifs::setUser(Usuario* c){ this->user = c;};
Usuario* EstrategiaNotifs::getUser(){ return user;};
